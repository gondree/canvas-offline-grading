#!/usr/bin/env python3

# A sample good "Hello World" submission

print("Hello World")
