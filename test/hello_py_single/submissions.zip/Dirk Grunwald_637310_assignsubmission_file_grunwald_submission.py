#!/usr/bin/env python3

# A sample bad "Hello World" submission

print("Broken World")
